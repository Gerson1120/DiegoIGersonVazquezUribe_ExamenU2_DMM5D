import { Image } from "@rneui/themed";
import { StyleSheet, Text, View } from "react-native";

Perfil=()=>{
    return(
        <View style={styles.container}>
            <Text style={{color:'white', fontWeight:'bold'}}>kanyewest</Text>
            <Image source={require('./assets/kw.jpg')} style={styles.image} />
            <Text style={{color:'white', fontWeight:'normal'}}>9 Publicaciones</Text>
            <Text style={{color:'white', fontWeight:'normal'}}>24M Seguidores</Text>
            <Text style={{color:'white', fontWeight:'normal'}}>0 Seguidos</Text>
            <View style={styles.imageContainer}>
        <Image source={require('./assets/tb.jpg')} style={styles.image} />
        <Image source={require('./assets/halcon.jpg')} style={styles.image} />
        <Image source={require('./assets/q.jpg')} style={styles.image} />
        <Image source={require('./assets/splhcb.jpg')} style={styles.image} />
        <Image source={require('./assets/kw.jpg')} style={styles.image} />
        <Image source={require('./assets/off.jpg')} style={styles.image} />
      </View>
        </View>
    )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    backgroundColor: '#000000',
  },
  imageContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  image: {
    marginBottom: 10,
    borderRadius: 8,
  },
});

export default Perfil;