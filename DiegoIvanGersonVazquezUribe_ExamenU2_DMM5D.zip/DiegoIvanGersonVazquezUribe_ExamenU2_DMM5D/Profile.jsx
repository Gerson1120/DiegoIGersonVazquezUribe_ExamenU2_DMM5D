import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Button, Card, Image } from '@rneui/themed';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Modal, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { MaterialIcons } from '@expo/vector-icons';
import Perfil from './Perfil';
import { useNavigation } from '@react-navigation/native';

const Bottom=createBottomTabNavigator();

Profile=()=> {
  let [getmodalVisible, setModalVisible]=useState(false);
  let [getmodalVisible1, setModalVisible1]=useState(false);
  let [getmodalVisible2, setModalVisible2]=useState(false);
  let [getmodalVisible3, setModalVisible3]=useState(false);
  let [getmodalVisible4, setModalVisible4]=useState(false);
  let [getmodalVisible5, setModalVisible5]=useState(false);
  let [getmodalVisible6, setModalVisible6]=useState(false);

  const navigation = useNavigation();
  return (
<View style={styles.container}>
  <Text style={styles.title}>Instagram</Text>
      <Card.Divider/>
      <ScrollView style={styles.scrollView}>

        <View style={styles.space}>
        <Text style={{color:'white', fontWeight:'bold'}}>kanyewest</Text>
      <AntDesign name='ellipsis1' style={{fontSize: 20, color:'white'}}/>
      <Image
      source={require("./assets/kw.jpg")}
      style={{width:200, height:200}}
      onLongPress={()=>setModalVisible(true)}
      onPressOut={()=>setModalVisible(false)}
      />
      <Text style={{color:'white', fontWeight:'bold'}}>kanyewest</Text>
      <Text style={{color:'white'}}>Vultures 2 out now</Text>
      <StatusBar style="auto" />
      <Modal animationType='fade'
      visible={getmodalVisible}>
        <Image
        source={require("./assets/kw.jpg")}
        style={{width:400,height:400}}/>
        <Button title="Me gusta" color={"secondary"}/>
      </Modal>
      <AntDesign name='hearto' style={{fontSize: 20, color:'white'}}/>
      <AntDesign name='message1' style={{fontSize: 20, color:'white'}}/>
        </View>
        
        
      
<View style={styles.space}>
<Text style={{color:'white', fontWeight:'bold'}}>utez</Text>
      <AntDesign name='ellipsis1' style={{fontSize: 20, color:'white'}}/>
      <Image
      source={require("./assets/halcon.jpg")}
      style={{width:200, height:200}}
      onLongPress={()=>setModalVisible1(true)}
      onPressOut={()=>setModalVisible1(false)}
      />
      <Text style={{color:'white', fontWeight:'bold'}}>utez</Text>
      <Text style={{color:'white'}}>Mercadito Utez</Text>
      <StatusBar style="auto" />
      <Modal animationType='fade'
      visible={getmodalVisible1}>
        <Image
        source={require("./assets/halcon.jpg")}
        style={{width:400,height:400}}/>
        <Button title="Me gusta" color={"secondary"}/>
      </Modal>
      <AntDesign name='hearto' style={{fontSize: 20, color:'white'}}/>
      <AntDesign name='message1' style={{fontSize: 20, color:'white'}}/>
</View>


      
      <View style={styles.space}>
      <Text style={{color:'white', fontWeight:'bold'}}>off</Text>
      <AntDesign name='ellipsis1' style={{fontSize: 20, color:'white'}}/>
      <Image
      source={require("./assets/off.jpg")}
      style={{width:200, height:200}}
      onLongPress={()=>setModalVisible2(true)}
      onPressOut={()=>setModalVisible2(false)}
      />
      <Text style={{color:'white', fontWeight:'bold'}}>off</Text>
      <Text style={{color:'white'}}>buy it</Text>
      <StatusBar style="auto" />
      <Modal animationType='fade'
      visible={getmodalVisible2}>
        <Image
        source={require("./assets/off.jpg")}
        style={{width:400,height:400}}/>
        <Button title="Me gusta" color={"secondary"}/>
      </Modal>
      <AntDesign name='hearto' style={{fontSize: 20, color:'white'}}/>
      <AntDesign name='message1' style={{fontSize: 20, color:'white'}}/>
      </View>
      
      
      
<View style={styles.space}>
<Text style={{color:'white', fontWeight:'bold'}}>on</Text>
      <AntDesign name='ellipsis1' style={{fontSize: 20, color:'white'}}/>
      <Image
      source={require("./assets/on.jpg")}
      style={{width:200, height:200}}
      onLongPress={()=>setModalVisible3(true)}
      onPressOut={()=>setModalVisible3(false)}
      />
      <Text style={{color:'white', fontWeight:'bold'}}>on</Text>
      <Text style={{color:'white'}}>buy it</Text>
      <StatusBar style="auto" />
      <Modal animationType='fade'
      visible={getmodalVisible3}>
        <Image
        source={require("./assets/on.jpg")}
        style={{width:400,height:400}}/>
        <Button title="Me gusta" color={"secondary"}/>
      </Modal>
      <AntDesign name='hearto' style={{fontSize: 20, color:'white'}}/>
      <AntDesign name='message1' style={{fontSize: 20, color:'white'}}/>
</View>


      
<View style={styles.space}>
<Text style={{color:'white', fontWeight:'bold'}}>queen</Text>
      <AntDesign name='ellipsis1' style={{fontSize: 20, color:'white'}}/>
      <Image
      source={require("./assets/q.jpg")}
      style={{width:200, height:200}}
      onLongPress={()=>setModalVisible4(true)}
      onPressOut={()=>setModalVisible4(false)}
      />
      <Text style={{color:'white', fontWeight:'bold'}}>queen</Text>
      <Text style={{color:'white'}}>Like if you like Queen</Text>
      <StatusBar style="auto" />
      <Modal animationType='fade'
      visible={getmodalVisible4}>
        <Image
        source={require("./assets/q.jpg")}
        style={{width:400,height:400}}/>
        <Button title="Me gusta" color={"secondary"}/>
      </Modal>
      <AntDesign name='hearto' style={{fontSize: 20, color:'white'}}/>
      <AntDesign name='message1' style={{fontSize: 20, color:'white'}}/>
</View>


      
<View style={styles.space}>
<Text style={{color:'white', fontWeight:'bold'}}>thebeatles</Text>
      <AntDesign name='ellipsis1' style={{fontSize: 20, color:'white'}}/>
      <Image
      source={require("./assets/splhcb.jpg")}
      style={{width:200, height:200}}
      onLongPress={()=>setModalVisible5(true)}
      onPressOut={()=>setModalVisible5(false)}
      />
      <Text style={{color:'white', fontWeight:'bold'}}>thebeatles</Text>
      <Text style={{color:'white'}}>Now and Then out now</Text>
      <StatusBar style="auto" />
      <Modal animationType='fade'
      visible={getmodalVisible5}>
        <Image
        source={require("./assets/splhcb.jpg")}
        style={{width:400,height:400}}/>
        <Button title="Me gusta" color={"secondary"}/>
      </Modal>
      <AntDesign name='hearto' style={{fontSize: 20, color:'white'}}/>
      <AntDesign name='message1' style={{fontSize: 20, color:'white'}}/>
</View>


      
<View style={styles.space}>
<Text style={{color:'white', fontWeight:'bold'}}>johnlenon</Text>
      <AntDesign name='ellipsis1' style={{fontSize: 20, color:'white'}}/>
      <Image
      source={require("./assets/tb.jpg")}
      style={{width:200, height:200}}
      onLongPress={()=>setModalVisible6(true)}
      onPressOut={()=>setModalVisible6(false)}
      />
      <Text style={{color:'white', fontWeight:'bold'}}>johnlenon</Text>
      <Text style={{color:'white'}}>thebeatles</Text>
      <StatusBar style="auto" />
      <Modal animationType='fade'
      visible={getmodalVisible6}>
        <Image
        source={require("./assets/tb.jpg")}
        style={{width:400,height:400}}/>
        <Button title="Me gusta" color={"secondary"}/>
      </Modal>
      <AntDesign name='hearto' style={{fontSize: 20, color:'white'}}/>
      <AntDesign name='message1' style={{fontSize: 20, color:'white'}}/>
</View>


      
      <Bottom.Navigator>
        <Bottom.Screen name={"Perfil"} component={Perfil}
        options={{
          tabBarIcon:({size,color})=>(
            <TouchableOpacity onPress={() => navigation.navigate('Perfil')}>
<MaterialIcons name="emoji-emotions" size={size} color={color}/>
            </TouchableOpacity>
            
          )
        }} />
        <Bottom.Screen name={"Search"} component={Search}
        options={{
          tabBarIcon:({size,color})=>(
            <TouchableOpacity onPress={() => navigation.navigate('Search')}>
<MaterialIcons name="search" size={size} color={color}/>
            </TouchableOpacity>
            
          )
        }} />
      </Bottom.Navigator>
      </ScrollView>     
      
    </View>
  );
}
export default Profile;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020002',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 30,
    marginBottom: 10,
  },
  scrollView: {
    backgroundColor: 'black',
    marginHorizontal: 20,
  },
  card:{
    backgroundColor: "000000"
  },
  space: {
    marginBottom: 20
  }
});