import React from 'react';
import { MaterialIcons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Image } from '@rneui/themed';
import { StyleSheet, TextInput, View, TouchableOpacity } from 'react-native';
import Perfil from './Perfil';

const Bottom = createBottomTabNavigator();

const Search = () => {
  return (
    <View style={styles.container}>
      <Bottom.Navigator>
        <Bottom.Screen
          name={'Perfil'}
          component={Perfil}
          options={{
            tabBarIcon: ({ size, color }) => (
              <MaterialIcons name="search" size={size} color={color} />
            ),
          }}
        />
      </Bottom.Navigator>

      <TextInput style={styles.input}></TextInput>

      <View style={styles.imageContainer}>
        <Image source={require('./assets/tb.jpg')} style={styles.image} />
        <Image source={require('./assets/halcon.jpg')} style={styles.image} />
        <Image source={require('./assets/q.jpg')} style={styles.image} />
        <Image source={require('./assets/splhcb.jpg')} style={styles.image} />
        <Image source={require('./assets/kw.jpg')} style={styles.image} />
        <Image source={require('./assets/off.jpg')} style={styles.image} />
      </View>
      <Bottom.Navigator>
        <Bottom.Screen name={"Perfil"} component={Perfil}
        options={{
          tabBarIcon:({size,color})=>(
            <TouchableOpacity onPress={() => navigation.navigate('Perfil')}>
<MaterialIcons name="emoji-emotions" size={size} color={color}/>
            </TouchableOpacity>
            
          )
        }} />
        <Bottom.Screen name={"Search"} component={Search}
        options={{
          tabBarIcon:({size,color})=>(
            <TouchableOpacity onPress={() => navigation.navigate('Search')}>
<MaterialIcons name="search" size={size} color={color}/>
            </TouchableOpacity>
            
          )
        }} />
      </Bottom.Navigator>
    </View>
  );
};

export default Search;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020002',
    padding: 10,
  },
  input: {
    backgroundColor: '#A4A4A4',
    marginTop: 10,
    padding: 10,
    borderRadius: 8,
    width: '100%',
  },
  imageContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  image: {
    marginBottom: 10,
    borderRadius: 8,
  },
});
