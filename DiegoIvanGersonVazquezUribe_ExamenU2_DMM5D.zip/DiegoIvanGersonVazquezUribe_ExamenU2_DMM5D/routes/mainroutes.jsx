import { createStackNavigator } from "@react-navigation/stack";
import Profile from "../Profile";
import Search from "../Search";
import Perfil from "../Perfil";

const Stack=createStackNavigator();
MainRoutes=()=>{
    return(
        <Stack.Navigator>
            <Stack.Screen name={"Profile"} component={Profile} options={{headerShown: false}}/>
            <Stack.Screen name={"Perfil"} component={Perfil} options={{headerShown: false}}/>
            <Stack.Screen name={"Search"} component={Search} options={{headerShown: false}}/>
        </Stack.Navigator>
    )
}

export default MainRoutes;